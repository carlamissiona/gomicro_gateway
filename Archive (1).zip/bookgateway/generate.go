package main
//go:generate make proto
