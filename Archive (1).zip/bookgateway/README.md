# Bookgateway Service

This is the Bookgateway service

Generated with

```
micro new bookgateway
```

## Usage

Generate the proto code

```
make proto
```

Run the service

```
micro run .
```