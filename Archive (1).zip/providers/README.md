# Providers Service

This is the Providers service

Generated with

```
micro new providers
```

## Usage

Generate the proto code

```
make proto
```

Run the service

```
micro run .
```