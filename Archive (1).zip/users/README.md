# Users Service

This is the Users service

Generated with

```
micro new users
```

## Usage

Generate the proto code

```
make proto
```

Run the service

```
micro run .
```