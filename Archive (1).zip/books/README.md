# Books Service

This is the Books service

Generated with

```
micro new books
```

## Usage

Generate the proto code

```
make proto
```

Run the service

```
micro run .
```